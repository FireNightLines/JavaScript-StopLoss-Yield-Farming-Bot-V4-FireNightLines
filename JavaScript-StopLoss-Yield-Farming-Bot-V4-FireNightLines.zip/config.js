var myaddress = "your ETH public address" // your ETH public address
var myprivatekey = "your privatekey to that address"  // your privatekey to the ETH public address you provided
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BSC-BNB , 3 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.
var stablecoineth = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" //USDC
var stablecoinbnb = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56" //BUSD
var stablecoinpolygon = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174" // USDC "USD Coin (PoS)"
var ethrpc = "https://ethereum.publicnode.com" //ETH rpc
var bscrpc = "https://bsc-dataseed4.binance.org" //BNB-BSC rpc
var polygonrpc = "https://rpc-mainnet.matic.network" //POLYGON rpc
